package com.clumsynx.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

val Red = Color(0xFFE5171F)
val Bg = Color(0xFF0A0A0C)
val CardBg = Color(0xFF17171B)
val Muted = Color(0xFF9A9AA3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Red, background = Bg, surface = CardBg,
                    onBackground = Color.White, onSurface = Color.White, onPrimary = Color.White
                )
            ) { App() }
        }
    }
}

fun fmt(t: Long): String =
    if (t == 0L) "бессрочно" else SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(t))

fun vpnCmd(ctx: Context, action: String?) {
    val i = Intent(ctx, ClumsyVpnService::class.java)
    if (action != null) i.action = action
    ctx.startService(i)
}

@Composable
fun Header(sub: String = "") {
    Column(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("ClumsyNX", color = Red, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
        if (sub.isNotEmpty()) Text(sub, color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val st = remember { Store(ctx) }
    val scope = rememberCoroutineScope()
    var role by remember { mutableStateOf("") } // "", user, dev, blocked
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(st.role == "user") }

    LaunchedEffect(Unit) {
        if (st.role == "user") {
            val err = withContext(Dispatchers.IO) { Repo.validate(st) }
            if (err == null) role = "user" else { role = "blocked"; msg = err }
            busy = false
        }
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        when {
            busy -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("ClumsyNX", color = Red, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                Text("Проверка доступа…", color = Muted)
            }
            role == "blocked" -> Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("ClumsyNX", color = Red, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(16.dp))
                Text(msg, color = Color.White, fontSize = 18.sp)
                Spacer(Modifier.height(16.dp))
                OutlinedButton(onClick = { st.role = ""; st.codeUsed = ""; role = "" }) { Text("Ввести другой код") }
            }
            role == "" -> LoginScreen(msg) { input, setErr, done ->
                scope.launch {
                    val (r, e) = withContext(Dispatchers.IO) { Repo.login(st, input) }
                    if (r.isEmpty()) { setErr(e); done(); return@launch }
                    if (r == "user") {
                        val err = withContext(Dispatchers.IO) { Repo.validate(st) }
                        if (err != null) { setErr(err); done(); return@launch }
                        st.role = "user"
                    }
                    role = r
                    done()
                }
            }
            else -> MainScreen(st, role == "dev") { st.role = ""; role = "" }
        }
    }
}

@Composable
fun LoginScreen(err: String, onLogin: (String, (String) -> Unit, () -> Unit) -> Unit) {
    var pw by remember { mutableStateOf("") }
    var e by remember { mutableStateOf(err) }
    var loading by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("ClumsyNX", color = Red, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
        Text("Введите пароль или код доступа", color = Muted)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = pw, onValueChange = { pw = it }, singleLine = true,
            label = { Text("Пароль / код") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        if (e.isNotEmpty()) Text(e, color = Red, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { loading = true; e = ""; onLogin(pw, { e = it }, { loading = false }) },
            enabled = !loading && pw.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = Red),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(if (loading) "Проверка…" else "Войти", fontSize = 17.sp) }
    }
}

@Composable
fun MainScreen(st: Store, isDev: Boolean, onLogout: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    var vals by remember { mutableStateOf(st.loadValues()) }
    var dir by remember { mutableStateOf(st.dir) }
    Params.v = vals
    Params.dir = dir

    fun applyCfg(nv: Map<String, Int>, nd: Int) {
        vals = nv; dir = nd
        Params.v = nv; Params.dir = nd
        st.saveValues(nv, nd)
    }

    val tabs = listOf("Главная", "Настройки", "Конфиги", "ИИ") + if (isDev) listOf("Админ") else emptyList()
    Column(Modifier.fillMaxSize()) {
        Header(if (isDev) "режим разработчика" else "")
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            tabs.forEachIndexed { i, t ->
                Button(
                    onClick = { tab = i },
                    modifier = Modifier.weight(1f).height(40.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (tab == i) Red else CardBg,
                        contentColor = Color.White
                    )
                ) { Text(t, fontSize = 12.sp, maxLines = 1) }
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)) {
            when (tab) {
                0 -> HomeTab(st, onLogout)
                1 -> SettingsTab(vals, dir, ::applyCfg)
                2 -> ConfigsTab(st, vals, dir) { v, d -> applyCfg(v, d) }
                3 -> AiTab { v -> applyCfg(v, dir) }
                else -> AdminTab(st)
            }
        }
    }
}

@Composable
fun HomeTab(st: Store, onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val running by VpnState.running
    val paused by VpnState.paused
    var smart by remember { mutableStateOf(st.smart) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) vpnCmd(ctx, null)
    }

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(8.dp))
        Text(
            when {
                !running -> "Выключено"
                paused -> "ИНТЕРНЕТ ОСТАНОВЛЕН"
                else -> "Работает"
            },
            color = if (paused) Red else Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(20.dp))
        if (!running) {
            Box(
                Modifier.size(190.dp).background(Color(0xFF1F7A3A), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Button(
                    onClick = {
                        val i = VpnService.prepare(ctx)
                        if (i != null) launcher.launch(i) else vpnCmd(ctx, null)
                    },
                    modifier = Modifier.size(190.dp),
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1F7A3A))
                ) { Text("ВКЛЮЧИТЬ", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            }
        } else {
            Button(
                onClick = { vpnCmd(ctx, if (paused) "RESUME" else "PAUSE") },
                modifier = Modifier.size(190.dp),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = Red)
            ) {
                Text(if (paused) "▶\nПРОДОЛЖИТЬ" else "❚❚\nПАУЗА", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(20.dp))
            OutlinedButton(onClick = { vpnCmd(ctx, "STOP") }) { Text("Выключить ClumsyNX") }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            if (running) "Пауза красная: пока нажата, интернет полностью стоит." else "Нажми «Включить» и дай разрешение на VPN.",
            color = Muted, fontSize = 13.sp
        )
        Spacer(Modifier.height(24.dp))

        Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("🛡", fontSize = 28.sp)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("ClumsyNX", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("  Бета", color = Color(0xFF3DDC84), fontSize = 12.sp)
                    }
                    Text(
                        "Умный режим. Автоматически выключает VPN, когда экран гаснет. Экономия заряда и производительности.",
                        color = Muted, fontSize = 13.sp
                    )
                }
                Switch(checked = smart, onCheckedChange = { smart = it; st.smart = it })
            }
        }
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = onLogout) { Text("Выйти из аккаунта") }
    }
}

@Composable
fun SettingsTab(vals: Map<String, Int>, dir: Int, apply: (Map<String, Int>, Int) -> Unit) {
    Text("Направление", color = Muted)
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("Оба", "Входящие", "Исходящие").forEachIndexed { i, t ->
            Button(
                onClick = { apply(vals, i) }, modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = if (dir == i) Red else CardBg, contentColor = Color.White)
            ) { Text(t, fontSize = 12.sp, maxLines = 1) }
        }
    }
    Keys.list.forEach { (k, title) ->
        val v = vals[k] ?: 0
        Text("$title: $v%", modifier = Modifier.padding(top = 10.dp))
        Slider(
            value = v.toFloat(), onValueChange = { apply(vals + (k to it.roundToInt()), dir) },
            valueRange = 0f..100f,
            colors = SliderDefaults.colors(thumbColor = Red, activeTrackColor = Red)
        )
    }
    Spacer(Modifier.height(8.dp))
    OutlinedButton(onClick = { apply(Keys.list.associate { it.first to 0 }, dir) }) { Text("Сбросить всё в 0%") }
}

@Composable
fun ConfigsTab(st: Store, vals: Map<String, Int>, dir: Int, apply: (Map<String, Int>, Int) -> Unit) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(st.configs()) }
    var name by remember { mutableStateOf("") }
    var imp by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    Text("Сохранить текущие настройки", color = Muted)
    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Название конфига") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Button(
        onClick = {
            val n = name.ifBlank { "Конфиг ${list.size + 1}" }
            list = (list + Cfg(n, vals, dir)).toMutableList(); st.saveConfigs(list); name = ""
        },
        colors = ButtonDefaults.buttonColors(containerColor = Red), modifier = Modifier.padding(top = 8.dp)
    ) { Text("Сохранить") }

    Spacer(Modifier.height(16.dp))
    Text("Мои конфиги", color = Muted)
    if (list.isEmpty()) Text("Пока пусто", color = Muted)
    list.forEachIndexed { idx, c ->
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Column(Modifier.padding(12.dp)) {
                Text(c.name, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { apply(c.v, c.dir) }) { Text("Применить", fontSize = 12.sp) }
                    OutlinedButton(onClick = {
                        val s = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, c.share())
                        ctx.startActivity(Intent.createChooser(s, "Поделиться конфигом").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }) { Text("Поделиться", fontSize = 12.sp) }
                    OutlinedButton(onClick = {
                        list = list.filterIndexed { i, _ -> i != idx }.toMutableList(); st.saveConfigs(list)
                    }) { Text("Удалить", fontSize = 12.sp) }
                }
            }
        }
    }

    Spacer(Modifier.height(16.dp))
    Text("Импорт конфига от друга", color = Muted)
    OutlinedTextField(value = imp, onValueChange = { imp = it }, label = { Text("Вставь код CNX1:…") }, modifier = Modifier.fillMaxWidth())
    Button(
        onClick = {
            val c = Cfg.parse(imp)
            if (c == null) note = "Не удалось прочитать конфиг" else {
                list = (list + c).toMutableList(); st.saveConfigs(list); imp = ""; note = "Добавлено: ${c.name}"
            }
        },
        colors = ButtonDefaults.buttonColors(containerColor = Red), modifier = Modifier.padding(top = 8.dp)
    ) { Text("Импортировать") }
    if (note.isNotEmpty()) Text(note, color = Muted)
}

@Composable
fun AiTab(onResult: (Map<String, Int>) -> Unit) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    Text("ИИ-настройка (тест)", fontWeight = FontWeight.Bold, fontSize = 18.sp)
    Text(
        "Замеряет пинг, джиттер и потери твоего интернета и сам расставляет ползунки. " +
            "Это тестовый локальный алгоритм, не облачная нейросеть.",
        color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp)
    )
    Button(
        onClick = {
            busy = true; text = "Замеряю…"
            scope.launch {
                val r = withContext(Dispatchers.IO) { Tuner.run() }
                onResult(r.values)
                text = "Пинг ${r.avg} мс, джиттер ${r.jitter} мс, потери ${r.loss}%.\nНастройки подобраны и применены — проверь вкладку «Настройки»."
                busy = false
            }
        },
        enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Red),
        modifier = Modifier.fillMaxWidth().height(52.dp)
    ) { Text("Подобрать автоматически") }
    if (text.isNotEmpty()) Text(text, modifier = Modifier.padding(top = 12.dp))
}

@Composable
fun AdminTab(st: Store) {
    var sub by remember { mutableStateOf(0) }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        listOf("Коды", "Пользователи").forEachIndexed { i, t ->
            Button(
                onClick = { sub = i }, modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = if (sub == i) Red else CardBg, contentColor = Color.White)
            ) { Text(t) }
        }
    }
    if (!Backend.enabled) {
        Text(
            "Сервер не подключён: коды и пользователи хранятся только на этом телефоне. " +
                "Чтобы они работали на всех устройствах, впиши Firebase в Config (Backend.kt).",
            color = Red, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp)
        )
    }
    if (sub == 0) CodesPanel(st) else UsersPanel(st)
}

@Composable
fun CodesPanel(st: Store) {
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf(listOf<CodeRec>()) }
    var label by remember { mutableStateOf("") }
    var days by remember { mutableStateOf("30") }
    var maxDev by remember { mutableStateOf("1") }
    var tick by remember { mutableStateOf(0) }

    LaunchedEffect(tick) { list = withContext(Dispatchers.IO) { Repo.codes(st) } }
    fun io(block: () -> Unit) { scope.launch { withContext(Dispatchers.IO) { block() }; tick++ } }

    Spacer(Modifier.height(8.dp))
    Text("Новый код", color = Muted)
    OutlinedTextField(value = label, onValueChange = { label = it }, label = { Text("Кому / заметка") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = days, onValueChange = { days = it.filter(Char::isDigit) }, label = { Text("Дней (0 = ∞)") },
            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
        )
        OutlinedTextField(
            value = maxDev, onValueChange = { maxDev = it.filter(Char::isDigit) }, label = { Text("Устройств") },
            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f)
        )
    }
    Button(
        onClick = {
            val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
            val code = (1..10).map { chars.random() }.joinToString("")
            val d = days.toLongOrNull() ?: 0L
            val exp = if (d == 0L) 0L else System.currentTimeMillis() + d * 86400000L
            val md = (maxDev.toIntOrNull() ?: 1).coerceAtLeast(1)
            io { Repo.putCode(st, CodeRec(code, label, true, exp, md, emptyList())) }
            label = ""
        },
        colors = ButtonDefaults.buttonColors(containerColor = Red), modifier = Modifier.padding(top = 8.dp)
    ) { Text("Создать код") }

    Spacer(Modifier.height(16.dp))
    Text("Коды (${list.size})", color = Muted)
    list.forEach { c ->
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.code, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        if (c.label.isNotBlank()) Text(c.label, color = Muted, fontSize = 12.sp)
                        Text("До: ${fmt(c.expires)} · устройств ${c.devices.size}/${c.maxDev}", color = Muted, fontSize = 12.sp)
                    }
                    Switch(checked = c.active, onCheckedChange = { v -> io { Repo.putCode(st, c.copy(active = v)) } })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(onClick = {
                        val base = if (c.expires == 0L) System.currentTimeMillis() else maxOf(c.expires, System.currentTimeMillis())
                        io { Repo.putCode(st, c.copy(expires = base + 86400000L)) }
                    }) { Text("+1 д", fontSize = 11.sp) }
                    OutlinedButton(onClick = {
                        val base = if (c.expires == 0L) System.currentTimeMillis() else maxOf(c.expires, System.currentTimeMillis())
                        io { Repo.putCode(st, c.copy(expires = base + 30 * 86400000L)) }
                    }) { Text("+30 д", fontSize = 11.sp) }
                    OutlinedButton(onClick = { io { Repo.putCode(st, c.copy(maxDev = c.maxDev + 1)) } }) { Text("+устр.", fontSize = 11.sp) }
                    OutlinedButton(onClick = { io { Repo.putCode(st, c.copy(devices = emptyList())) } }) { Text("Сброс", fontSize = 11.sp) }
                    OutlinedButton(onClick = { io { Repo.delCode(st, c.code) } }) { Text("Удалить", fontSize = 11.sp) }
                }
            }
        }
    }
}

@Composable
fun UsersPanel(st: Store) {
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf(listOf<UserRec>()) }
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(tick) { list = withContext(Dispatchers.IO) { Repo.users(st) } }

    Spacer(Modifier.height(8.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Пользователи (${list.size})", color = Muted, modifier = Modifier.weight(1f))
        OutlinedButton(onClick = { tick++ }) { Text("Обновить") }
    }
    list.sortedByDescending { it.lastSeen }.forEach { u ->
        Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(u.model.ifBlank { "Устройство" }, fontWeight = FontWeight.Bold)
                    Text("ID ${u.id} · код ${u.code.ifBlank { "—" }}", color = Muted, fontSize = 12.sp)
                    Text("Был: ${fmt(u.lastSeen)}", color = Muted, fontSize = 12.sp)
                    Text(if (u.banned) "ЗАБЛОКИРОВАН" else "активен", color = if (u.banned) Red else Color(0xFF3DDC84), fontSize = 12.sp)
                }
                Button(
                    onClick = {
                        scope.launch { withContext(Dispatchers.IO) { Repo.putUser(st, u.copy(banned = !u.banned)) }; tick++ }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (u.banned) CardBg else Red)
                ) { Text(if (u.banned) "Разбанить" else "Бан", fontSize = 12.sp) }
            }
        }
    }
}
