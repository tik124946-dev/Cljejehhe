package com.clumsynx.app

import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.sqrt

/**
 * ИИ-подбор (тест). Это локальный алгоритм без облака: замеряет пинг, джиттер и потери
 * до интернета и подбирает ползунки под твоё соединение.
 */
object Tuner {
    class Result(val avg: Int, val jitter: Int, val loss: Int, val values: Map<String, Int>)

    fun run(): Result {
        val rtts = ArrayList<Long>()
        var fails = 0
        val tries = 10
        for (i in 0 until tries) {
            val t = System.currentTimeMillis()
            try {
                Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
                rtts.add(System.currentTimeMillis() - t)
            } catch (e: Exception) {
                fails++
            }
            try { Thread.sleep(80) } catch (e: Exception) { }
        }
        val avg = if (rtts.isEmpty()) 999 else rtts.average().toInt()
        val jit = if (rtts.size < 2) 0 else {
            val m = rtts.average()
            sqrt(rtts.sumOf { (it - m) * (it - m) } / rtts.size).toInt()
        }
        val loss = fails * 100 / tries

        // качество 0..100: чем стабильнее интернет, тем сильнее можно «давить» без разрыва связи
        val q = (100 - avg / 4 - jit * 2 - loss * 3).coerceIn(5, 100)
        fun s(x: Int) = (x * q / 100).coerceIn(0, 100)
        val vals = mapOf(
            "loss" to s(12),
            "delay" to (s(30) - avg / 10).coerceAtLeast(0),
            "jitter" to s(18),
            "spike" to s(6),
            "dup" to s(5),
            "reorder" to s(6),
            "corrupt" to s(2),
            "throttle" to s(10)
        )
        return Result(avg, jit, loss, vals)
    }
}
