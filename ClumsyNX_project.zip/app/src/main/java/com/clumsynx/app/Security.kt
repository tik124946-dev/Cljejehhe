package com.clumsynx.app

import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Пароли в коде не хранятся: только соль и PBKDF2-хэш. */
object Security {
    private const val ITER = 100000

    private const val U_SALT = "0fdbd3f395393f0f5ee24c9d3ee88d21"
    private const val U_HASH = "eac925f213ae43840f8a073a302244dffe338e6c786e6c31704769ab63582371"
    private const val D_SALT = "2f16376a27c7350d706fc0318bec0035"
    private const val D_HASH = "3b75c34b80bb06d8f48e6671c26c5a673eb1c713dd204bc1fe61995cbf0d57d2"

    private fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    private fun pbkdf2(pw: ByteArray, salt: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(pw, "HmacSHA256"))
        mac.update(salt)
        mac.update(byteArrayOf(0, 0, 0, 1))
        var u = mac.doFinal()
        val t = u.copyOf()
        for (i in 1 until ITER) {
            u = mac.doFinal(u)
            for (j in t.indices) t[j] = (t[j].toInt() xor u[j].toInt()).toByte()
        }
        return t
    }

    private fun check(input: String, salt: String, hash: String): Boolean {
        val s = input.trim()
        if (s.isEmpty()) return false
        return MessageDigest.isEqual(pbkdf2(s.toByteArray(Charsets.UTF_8), unhex(salt)), unhex(hash))
    }

    fun isUser(p: String) = check(p, U_SALT, U_HASH)
    fun isDev(p: String) = check(p, D_SALT, D_HASH)
}
