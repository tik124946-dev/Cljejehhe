plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.clumsynx.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.clumsynx.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    signingConfigs {
        create("main") {
            storeFile = file("clumsynx.jks")
            storePassword = "clumsynx"
            keyAlias = "clumsynx"
            keyPassword = "clumsynx"
        }
    }

    buildTypes {
        debug { signingConfig = signingConfigs.getByName("main") }
        release {
            signingConfig = signingConfigs.getByName("main")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
}
